# FWD Weed-Laser Mower Manufacturing CAD Concept — Iteration 2

This package is intended for import into SolidWorks and contains a prototype
mechanical architecture for the complete mower, cutting system, and sealed
weed-laser mechanism.

## Start here

Open `assembly/mower_manufacturing_assembly.step` for the complete product.
For detailed inspection, open:

- `assembly/mower_service_view.step`
- `assembly/cutting_deck_subassembly.step`
- `assembly/cutting_deck_exploded_view.step`
- `assembly/sealed_laser_pod_subassembly.step`
- `assembly/laser_internal_gimbal_service_view.step`

The `parts` folder contains 27 individual STEP components. The `source` folder
contains the parametric CadQuery generator. All dimensions are millimetres.

## Important status

This is a manufacturable prototype concept, not a production release. Supplier
parts, materials, tolerances, sealing, blade containment, optical performance,
laser classification, interlocks, structural analysis, and regulatory
compliance require engineering validation before any physical build.

See `docs/DESIGN_NOTES.md`, `docs/BOM.csv`, and
`docs/SOLIDWORKS_IMPORT_AND_MATES.md` before modifying the design. The completed
geometry review and interference results are in `docs/FINAL_AUDIT.md`.
