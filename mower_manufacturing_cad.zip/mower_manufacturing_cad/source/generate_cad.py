#!/usr/bin/env python3
"""Generate a SolidWorks-friendly manufacturing concept for the robotic mower.

Outputs individual STEP parts and a STEP assembly. Units are millimetres.
This is a prototype mechanical architecture, not production certification.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

import cadquery as cq
from cadquery import exporters, importers


ROOT = Path(__file__).resolve().parents[1]
PARTS = ROOT / "parts"
ASSEMBLY = ROOT / "assembly"
DOCS = ROOT / "docs"
for directory in (PARTS, ASSEMBLY, DOCS):
    directory.mkdir(parents=True, exist_ok=True)


def rounded_box(x: float, y: float, z: float, radius: float) -> cq.Workplane:
    """Box centred at the origin with rounded vertical corners."""
    solid = cq.Workplane("XY").box(x, y, z)
    return solid.edges("|Z").fillet(radius)


def rounded_plate(x: float, y: float, z: float, radius: float) -> cq.Workplane:
    return rounded_box(x, y, z, radius)


def superellipse_points(length: float, width: float, exponent: float = 4.0, count: int = 72):
    points = []
    power = 2.0 / exponent
    for index in range(count):
        theta = 2.0 * math.pi * index / count
        c, s = math.cos(theta), math.sin(theta)
        x = 0.5 * length * math.copysign(abs(c) ** power, c)
        y = 0.5 * width * math.copysign(abs(s) ** power, s)
        points.append((x, y))
    return points


def loft_profiles(sections):
    workplane = cq.Workplane("XY")
    current_z = 0.0
    for z_value, length, width in sections:
        workplane = workplane.workplane(offset=z_value - current_z)
        workplane = workplane.polyline(superellipse_points(length, width)).close()
        current_z = z_value
    return workplane.loft(combine=True, ruled=False)


def cut_drive_wheel_wells(
    part: cq.Workplane,
    wheel_center_z_local: float,
    clearance_radius: float = 124,
) -> cq.Workplane:
    """Cut side-localized wheel envelopes without opening the chassis centre."""
    for side in (-1, 1):
        cutter = (
            cq.Workplane("XZ")
            .center(120, wheel_center_z_local)
            .circle(clearance_radius)
            .extrude(42, both=True)
            .translate((0, side * 239, 0))
        )
        part = part.cut(cutter)
    return part


def export_step(name: str, part: cq.Workplane) -> None:
    exporters.export(part, str(PARTS / f"{name}.step"))


def make_upper_cover():
    outer = loft_profiles([
        (65, 700, 470),
        (145, 680, 455),
        (245, 545, 365),
        (295, 390, 275),
    ])
    inner = loft_profiles([
        (61, 692, 462),
        (145, 672, 447),
        (243, 537, 357),
        (288, 382, 267),
    ])
    cover = outer.cut(inner)
    wheel_arch = (
        cq.Workplane("XZ")
        .center(120, 120)
        .circle(134)
        .extrude(600, both=True)
    )
    cover = cover.cut(wheel_arch)
    # Replaceable sealed laser pod occupies a dedicated front-cover opening;
    # 2 mm assembly clearance is reserved around the pod envelope.
    pod_clearance = rounded_box(154, 148, 104, 14).translate((255, 0, 144))
    cover = cover.cut(pod_clearance)
    chassis_clearance = rounded_box(658, 438, 24, 32).translate((0, 0, 74))
    return cover.cut(chassis_clearance)


def make_base_plate():
    plate = rounded_plate(650, 430, 4, 28)
    plate = plate.faces(">Z").workplane().center(-30, 0).circle(171).cutThruAll()
    chassis_holes = [
        (-310, 0), (310, 0), (0, -200), (0, 200),
        (-220, -200), (-220, 200), (220, -200), (220, 200),
    ]
    plate = plate.faces(">Z").workplane().pushPoints(chassis_holes).hole(5.2)
    guide_holes = []
    for angle in (60, 180, 300):
        guide_holes.append((-30 + 145 * math.cos(math.radians(angle)), 145 * math.sin(math.radians(angle))))
    plate = plate.faces(">Z").workplane().pushPoints(guide_holes).hole(10.2)
    plate = plate.faces(">Z").workplane().pushPoints([(113, 0)]).hole(12.0)
    kingpin_cut = cq.Workplane("XY").circle(11.1).extrude(20, both=True).translate((-285, 0, 0))
    plate = plate.cut(kingpin_cut)
    caster_mounts = [(-313, -22), (-313, 22), (-257, -22), (-257, 22)]
    plate = plate.faces(">Z").workplane().pushPoints(caster_mounts).hole(5.2)
    pod_mounts = [(203, -48), (203, 48), (307, -48), (307, 48)]
    plate = plate.faces(">Z").workplane().pushPoints(pod_mounts).hole(5.2)
    return cut_drive_wheel_wells(plate, wheel_center_z_local=50)


def make_chassis_reinforcement_frame():
    left_rail = cq.Workplane("XY").box(540, 16, 20).translate((0, 188, 0))
    right_rail = cq.Workplane("XY").box(540, 16, 20).translate((0, -188, 0))
    front_cross = cq.Workplane("XY").box(25, 376, 20).translate((245, 0, 0))
    # Split the rear crossmember around the caster kingpin/mount envelope.
    rear_left = cq.Workplane("XY").box(25, 151, 20).translate((-245, 120.5, 0))
    rear_right = cq.Workplane("XY").box(25, 151, 20).translate((-245, -120.5, 0))
    return left_rail.union(right_rail).union(front_cross).union(rear_left).union(rear_right)


def make_cover_mounting_flange():
    # A connected internal frame avoids the wheel, motor-bracket, caster, and
    # laser-standoff envelopes while still supporting the removable cover.
    front = cq.Workplane("XY").box(40, 420, 4).translate((300, 0, 0))
    rear = cq.Workplane("XY").box(40, 420, 4).translate((-300, 0, 0))
    left = cq.Workplane("XY").box(600, 20, 4).translate((0, 145, 0))
    right = cq.Workplane("XY").box(600, 20, 4).translate((0, -145, 0))
    flange = front.union(rear).union(left).union(right)
    caster_envelope = rounded_box(92, 84, 10, 8).translate((-285, 0, 0))
    flange = flange.cut(caster_envelope)
    points = [
        (-310, 0), (310, 0), (0, -200), (0, 200),
        (-220, -200), (-220, 200), (220, -200), (220, 200),
    ]
    cutters = cq.Workplane("XY").pushPoints(points).circle(2.6).extrude(10, both=True)
    flange = flange.cut(cutters)
    pod_mounts = [(203, -48), (203, 48), (307, -48), (307, 48)]
    pod_clearance = cq.Workplane("XY").pushPoints(pod_mounts).circle(8.5).extrude(10, both=True)
    return flange.cut(pod_clearance)


def make_drive_tire():
    tire = cq.Workplane("XZ").circle(120).circle(82).extrude(32, both=True)
    try:
        return tire.edges().fillet(7)
    except Exception:
        return tire


def make_drive_hub():
    # Keep the inboard face clear of the motor bracket while retaining a
    # 24 mm total hub width for the selected wheel envelope.
    hub = cq.Workplane("XZ").circle(80).extrude(12, both=True)
    hub = hub.cut(cq.Workplane("XZ").circle(18).extrude(30, both=True))
    points = []
    for angle in range(0, 360, 60):
        points.append((52 * math.cos(math.radians(angle)), 52 * math.sin(math.radians(angle))))
    holes = cq.Workplane("XZ").pushPoints(points).circle(3.3).extrude(30, both=True)
    return hub.cut(holes)


def make_wheel_motor_bracket():
    flange = rounded_plate(100, 55, 5, 6).translate((0, 0, 2.5))
    upright = cq.Workplane("XY").box(100, 5, 96).translate((0, -25, 48))
    bracket = flange.union(upright)
    axle_cut = cq.Workplane("XZ").center(0, 48).circle(26).extrude(40, both=True)
    bracket = bracket.cut(axle_cut)
    mount_points = [(-38, 14), (38, 14), (-38, -14), (38, -14)]
    bracket = bracket.faces("<Z").workplane().pushPoints(mount_points).hole(5.2)
    return bracket


def make_caster_wheel():
    # Compact rear support sized to fit below the 68 mm chassis underside.
    wheel = cq.Workplane("XZ").circle(30).circle(12).extrude(12, both=True)
    try:
        return wheel.edges().fillet(5)
    except Exception:
        return wheel


def make_caster_fork():
    # Wheel top is Z=30 locally; the bridge starts at Z=31 for 1 mm clearance.
    top = rounded_plate(72, 58, 6, 7).translate((0, 0, 34))
    arm_l = cq.Workplane("XY").box(54, 6, 31).translate((0, 20, 15.5))
    arm_r = cq.Workplane("XY").box(54, 6, 31).translate((0, -20, 15.5))
    kingpin = cq.Workplane("XY").workplane(offset=37).circle(10).extrude(11)
    fork = top.union(arm_l).union(arm_r).union(kingpin)
    axle = cq.Workplane("XZ").circle(6.2).extrude(50, both=True)
    return fork.cut(axle)


def make_caster_mount():
    mount = rounded_plate(80, 70, 6, 8)
    mount = mount.faces(">Z").workplane().hole(22.2)
    pts = [(-28, -22), (-28, 22), (28, -22), (28, 22)]
    return mount.faces(">Z").workplane().pushPoints(pts).hole(5.2)


def make_pod_standoff():
    standoff = cq.Workplane("XY").circle(8).extrude(24)
    return standoff.cut(cq.Workplane("XY").circle(2.6).extrude(24))


def make_deck_guard():
    wall = cq.Workplane("XY").circle(178).circle(169).extrude(35)
    top_ring = cq.Workplane("XY").workplane(offset=32).circle(178).circle(150).extrude(3)
    return wall.union(top_ring)


def make_deck_carriage():
    plate = cq.Workplane("XY").circle(166).extrude(4)
    plate = plate.faces(">Z").workplane().circle(43).cutThruAll()
    guide_pts = []
    for angle in (60, 180, 300):
        guide_pts.append((145 * math.cos(math.radians(angle)), 145 * math.sin(math.radians(angle))))
    plate = plate.faces(">Z").workplane().pushPoints(guide_pts).hole(10.2)
    plate = plate.faces(">Z").workplane().pushPoints([(143, 0)]).hole(12.0)
    motor_pts = []
    for angle in (0, 90, 180, 270):
        motor_pts.append((34 * math.cos(math.radians(angle)), 34 * math.sin(math.radians(angle))))
    return plate.faces(">Z").workplane().pushPoints(motor_pts).hole(5.2)


def make_blade_disc():
    disc = cq.Workplane("XY").circle(145).extrude(3)
    disc = disc.faces(">Z").workplane().circle(8).cutThruAll()
    disc = disc.faces(">Z").workplane().pushPoints([(0, 20), (17.32, -10), (-17.32, -10)]).hole(5.2)
    pivots = []
    for angle in (0, 120, 240):
        pivots.append((116 * math.cos(math.radians(angle)), 116 * math.sin(math.radians(angle))))
    return disc.faces(">Z").workplane().pushPoints(pivots).hole(5.5)


def make_cutting_blade():
    # The local origin is the pivot-hole centre so assembly placement is exact.
    # Envelope is -8 to +42 mm from the pivot, leaving >10 mm guard clearance.
    blade = rounded_plate(50, 18, 1.2, 3).translate((17, 0, 0))
    pivot_hole = cq.Workplane("XY").circle(2.75).extrude(4, both=True)
    return blade.cut(pivot_hole)


def make_blade_motor_proxy():
    body = cq.Workplane("XY").circle(42).extrude(62)
    flange = cq.Workplane("XY").circle(51).extrude(5)
    shaft = cq.Workplane("XY").workplane(offset=-38).circle(6).extrude(45)
    return body.union(flange).union(shaft)


def make_guide_rod():
    return cq.Workplane("XY").circle(4).extrude(90)


def make_lead_screw():
    return cq.Workplane("XY").circle(5).extrude(105)


def make_laser_pod_body():
    outer = rounded_box(150, 144, 92, 12)
    inner = rounded_box(136, 130, 82, 8).translate((0, 0, 8))
    body = outer.cut(inner)
    window_cut = rounded_box(88, 66, 28, 7).rotate((0, 0, 0), (0, 1, 0), -25).translate((28, 0, -39))
    body = body.cut(window_cut)
    # Machined retainer seat and matching angled M4 clearance holes prevent the
    # external frame from occupying the pod wall volume.
    retainer_pocket = rounded_box(94, 72, 5, 9).rotate((0, 0, 0), (0, 1, 0), -25).translate((29.5, 0, -42.2))
    body = body.cut(retainer_pocket)
    retainer_holes = (
        cq.Workplane("XY")
        .pushPoints([(-38, -27), (-38, 27), (38, -27), (38, 27)])
        .circle(2.1)
        .extrude(20, both=True)
        .rotate((0, 0, 0), (0, 1, 0), -25)
        .translate((29.5, 0, -42.2))
    )
    body = body.cut(retainer_holes)
    # Baffled internal line-of-sight tunnel from the tilt pivot to the window.
    # This prevents the cartridge/lens flange from touching the enclosure floor.
    optical_tunnel = (
        cq.Workplane("XY")
        .workplane(offset=-55)
        .circle(28)
        .extrude(55)
        .rotate((0, 0, 0), (0, 1, 0), -35)
        .translate((0, 0, 5))
    )
    body = body.cut(optical_tunnel)
    lid_holes = [(-58, -53), (-58, 53), (58, -53), (58, 53)]
    cutters = cq.Workplane("XY").pushPoints(lid_holes).circle(2.6).extrude(120, both=True)
    body = body.cut(cutters)
    pod_mounts = [(-52, -48), (-52, 48), (52, -48), (52, 48)]
    mount_cutters = cq.Workplane("XY").pushPoints(pod_mounts).circle(2.6).extrude(120, both=True)
    body = body.cut(mount_cutters)
    # Six-millimetre purge port feeding an external air knife along the window.
    purge = cq.Workplane("XZ").center(40, -25).circle(3.2).extrude(100, both=True)
    return body.cut(purge)


def make_laser_pod_lid():
    lid = rounded_plate(150, 144, 5, 12)
    holes = [(-58, -53), (-58, 53), (58, -53), (58, 53)]
    lid = lid.faces(">Z").workplane().pushPoints(holes).hole(5.2)
    return lid


def make_laser_window():
    return rounded_plate(82, 60, 3, 6)


def make_window_retainer():
    outer = rounded_plate(92, 70, 4, 8)
    inner = rounded_plate(76, 54, 8, 5)
    frame = outer.cut(inner)
    holes = [(-38, -27), (-38, 27), (38, -27), (38, 27)]
    return frame.faces(">Z").workplane().pushPoints(holes).hole(4.2)


def make_pan_plate():
    plate = cq.Workplane("XY").circle(38).extrude(7, both=True)
    plate = plate.cut(cq.Workplane("XY").circle(4.1).extrude(12, both=True))
    holes = [(-25, -18), (-25, 18), (25, -18), (25, 18)]
    return plate.faces(">Z").workplane().pushPoints(holes).hole(3.2)


def make_tilt_yoke():
    # A rear bridge keeps the optical path clear; ears sit on +/-Y so one
    # horizontal shoulder bolt defines the Y tilt axis.
    bridge = rounded_box(7, 60, 52, 2.5).translate((-48, 0, 0))
    left = rounded_box(96, 7, 52, 2.5).translate((-2, 28, 0))
    right = rounded_box(96, 7, 52, 2.5).translate((-2, -28, 0))
    yoke = bridge.union(left).union(right)
    pivot = cq.Workplane("XZ").center(0, 0).circle(5.3).extrude(70, both=True)
    return yoke.cut(pivot)


def make_emitter_cartridge():
    # Offset the tilt pivot toward the rear of the cartridge. The 48 mm front
    # reach aligns the lens with the window while the 24 mm rear reach clears
    # the pan plate through the complete pitch range.
    tube = cq.Workplane("XY").workplane(offset=-44).circle(16).extrude(64)
    lens_mount = cq.Workplane("XY").workplane(offset=-44).circle(20).extrude(6)
    pivot_outer = cq.Workplane("XZ").circle(8).extrude(24, both=True)
    pivot_inner = cq.Workplane("XZ").circle(5.1).extrude(30, both=True)
    pivot_sleeve = pivot_outer.cut(pivot_inner)
    return tube.union(lens_mount).union(pivot_sleeve)


def make_servo_proxy():
    body = rounded_box(24, 14, 30, 3)
    flange = rounded_plate(28, 14, 3, 2).translate((0, 0, 10))
    shaft = cq.Workplane("XY").workplane(offset=15).circle(3).extrude(7)
    return body.union(flange).union(shaft)


def make_pan_drive_pinion():
    pinion = cq.Workplane("XY").circle(6).extrude(10)
    return pinion.cut(cq.Workplane("XY").circle(3.1).extrude(10))


parts = {
    "upper_cover": make_upper_cover(),
    "lower_chassis_plate": make_base_plate(),
    "chassis_reinforcement_frame": make_chassis_reinforcement_frame(),
    "cover_mounting_flange": make_cover_mounting_flange(),
    "drive_tire": make_drive_tire(),
    "drive_hub": make_drive_hub(),
    "wheel_motor_bracket": make_wheel_motor_bracket(),
    "rear_caster_wheel": make_caster_wheel(),
    "rear_caster_fork": make_caster_fork(),
    "rear_caster_mount": make_caster_mount(),
    "laser_pod_standoff": make_pod_standoff(),
    "cutting_deck_guard": make_deck_guard(),
    "cut_height_carriage": make_deck_carriage(),
    "blade_carrier_disc": make_blade_disc(),
    "replaceable_cutting_blade": make_cutting_blade(),
    "blade_motor_proxy": make_blade_motor_proxy(),
    "cut_height_guide_rod": make_guide_rod(),
    "cut_height_lead_screw": make_lead_screw(),
    "laser_pod_body": make_laser_pod_body(),
    "laser_pod_lid": make_laser_pod_lid(),
    "laser_optical_window": make_laser_window(),
    "laser_window_retainer": make_window_retainer(),
    "laser_pan_plate": make_pan_plate(),
    "laser_tilt_yoke": make_tilt_yoke(),
    "laser_emitter_cartridge": make_emitter_cartridge(),
    "laser_servo_proxy": make_servo_proxy(),
    "laser_pan_drive_pinion": make_pan_drive_pinion(),
}

for part_name, model in parts.items():
    export_step(part_name, model)


assembly = cq.Assembly(name="FWD_weed_laser_mower_manufacturing_concept")
assembly.add(parts["upper_cover"], name="upper_cover", color=cq.Color(0.60, 0.63, 0.66, 0.85))
assembly.add(parts["lower_chassis_plate"], loc=cq.Location(cq.Vector(0, 0, 70)), name="lower_chassis_plate", color=cq.Color(0.15, 0.16, 0.17))
assembly.add(parts["chassis_reinforcement_frame"], loc=cq.Location(cq.Vector(0, 0, 58)), name="chassis_reinforcement_frame", color=cq.Color(0.25, 0.27, 0.29))
assembly.add(parts["cover_mounting_flange"], loc=cq.Location(cq.Vector(0, 0, 76)), name="cover_mounting_flange", color=cq.Color(0.30, 0.32, 0.34))

for side, label in ((1, "left"), (-1, "right")):
    assembly.add(parts["drive_tire"], loc=cq.Location(cq.Vector(120, side * 231, 120)), name=f"{label}_drive_tire", color=cq.Color(0.03, 0.03, 0.03))
    assembly.add(parts["drive_hub"], loc=cq.Location(cq.Vector(120, side * 231, 120)), name=f"{label}_drive_hub", color=cq.Color(0.32, 0.34, 0.36))
    bracket_loc = cq.Location(cq.Vector(120, side * 190, 72), cq.Vector(0, 0, 1), 180 if side < 0 else 0)
    assembly.add(parts["wheel_motor_bracket"], loc=bracket_loc, name=f"{label}_wheel_motor_bracket", color=cq.Color(0.25, 0.27, 0.29))

assembly.add(parts["rear_caster_mount"], loc=cq.Location(cq.Vector(-285, 0, 75)), name="rear_caster_mount", color=cq.Color(0.30, 0.32, 0.34))
assembly.add(parts["rear_caster_fork"], loc=cq.Location(cq.Vector(-285, 0, 30)), name="rear_caster_fork", color=cq.Color(0.28, 0.30, 0.32))
assembly.add(parts["rear_caster_wheel"], loc=cq.Location(cq.Vector(-285, 0, 30)), name="rear_caster_wheel", color=cq.Color(0.03, 0.03, 0.03))

# Cutting deck at the nominal 45 mm blade plane.
assembly.add(parts["cutting_deck_guard"], loc=cq.Location(cq.Vector(-30, 0, 28)), name="cutting_deck_guard", color=cq.Color(0.18, 0.19, 0.20))
assembly.add(parts["cut_height_carriage"], loc=cq.Location(cq.Vector(-30, 0, 80)), name="cut_height_carriage", color=cq.Color(0.32, 0.34, 0.36))
assembly.add(parts["blade_carrier_disc"], loc=cq.Location(cq.Vector(-30, 0, 47)), name="blade_carrier_disc", color=cq.Color(0.22, 0.24, 0.26))
assembly.add(parts["blade_motor_proxy"], loc=cq.Location(cq.Vector(-30, 0, 84)), name="blade_motor_proxy", color=cq.Color(0.18, 0.20, 0.22))
for index, angle in enumerate((0, 120, 240), start=1):
    radius = 116
    x = -30 + radius * math.cos(math.radians(angle))
    y = radius * math.sin(math.radians(angle))
    loc = cq.Location(cq.Vector(x, y, 45), cq.Vector(0, 0, 1), angle + 10)
    assembly.add(parts["replaceable_cutting_blade"], loc=loc, name=f"cutting_blade_{index}", color=cq.Color(0.75, 0.77, 0.79))
for index, angle in enumerate((60, 180, 300), start=1):
    x = -30 + 145 * math.cos(math.radians(angle))
    y = 145 * math.sin(math.radians(angle))
    assembly.add(parts["cut_height_guide_rod"], loc=cq.Location(cq.Vector(x, y, 55)), name=f"cut_height_guide_rod_{index}", color=cq.Color(0.55, 0.57, 0.59))
assembly.add(parts["cut_height_lead_screw"], loc=cq.Location(cq.Vector(113, 0, 50)), name="cut_height_lead_screw", color=cq.Color(0.60, 0.62, 0.64))

# Fixed external laser pod; all moving joints remain inside this sealed volume.
pod_origin = cq.Vector(255, 0, 142)
for index, (x, y) in enumerate(((203, -48), (203, 48), (307, -48), (307, 48)), start=1):
    assembly.add(parts["laser_pod_standoff"], loc=cq.Location(cq.Vector(x, y, 72)), name=f"laser_pod_standoff_{index}", color=cq.Color(0.45, 0.47, 0.49))
assembly.add(parts["laser_pod_body"], loc=cq.Location(pod_origin), name="laser_pod_body", color=cq.Color(0.12, 0.13, 0.14))
assembly.add(parts["laser_pod_lid"], loc=cq.Location(cq.Vector(255, 0, 190.5)), name="laser_pod_lid", color=cq.Color(0.95, 0.38, 0.04))
window_loc = cq.Location(cq.Vector(283, 0, 103), cq.Vector(0, 1, 0), -25)
assembly.add(parts["laser_optical_window"], loc=window_loc, name="laser_optical_window", color=cq.Color(0.35, 0.60, 0.75, 0.45))
retainer_loc = cq.Location(cq.Vector(284.5, 0, 99.8), cq.Vector(0, 1, 0), -25)
assembly.add(parts["laser_window_retainer"], loc=retainer_loc, name="laser_window_retainer", color=cq.Color(0.95, 0.38, 0.04))
assembly.add(parts["laser_pan_plate"], loc=cq.Location(cq.Vector(255, 0, 180)), name="laser_pan_plate", color=cq.Color(0.32, 0.34, 0.36))
assembly.add(parts["laser_tilt_yoke"], loc=cq.Location(cq.Vector(255, 0, 147)), name="laser_tilt_yoke", color=cq.Color(0.40, 0.42, 0.44))
emitter_loc = cq.Location(cq.Vector(255, 0, 147), cq.Vector(0, 1, 0), -35)
assembly.add(parts["laser_emitter_cartridge"], loc=emitter_loc, name="laser_emitter_cartridge", color=cq.Color(0.55, 0.18, 0.05))
assembly.add(parts["laser_servo_proxy"], loc=cq.Location(cq.Vector(255, -44, 155)), name="laser_pan_servo_proxy", color=cq.Color(0.15, 0.25, 0.40))
assembly.add(parts["laser_pan_drive_pinion"], loc=cq.Location(cq.Vector(255, -44, 171)), name="laser_pan_drive_pinion", color=cq.Color(0.55, 0.57, 0.59))
tilt_servo_loc = cq.Location(cq.Vector(255, 47.5, 147), cq.Vector(1, 0, 0), 90)
assembly.add(parts["laser_servo_proxy"], loc=tilt_servo_loc, name="laser_tilt_servo_proxy", color=cq.Color(0.15, 0.25, 0.40))

assembly_path = ASSEMBLY / "mower_manufacturing_assembly.step"
assembly.save(str(assembly_path))

# Service assembly without the upper shell.
service = cq.Assembly(name="mower_service_view_no_upper_cover")
for child in assembly.children:
    if child.name != "upper_cover":
        service.add(child.obj, loc=child.loc, name=child.name, color=child.color)
service.save(str(ASSEMBLY / "mower_service_view.step"))

# Cutting-deck subassembly at nominal 45 mm blade height.
cutting = cq.Assembly(name="cutting_deck_subassembly")
cutting.add(parts["cutting_deck_guard"], loc=cq.Location(cq.Vector(0, 0, -17)), name="guard")
cutting.add(parts["cut_height_carriage"], loc=cq.Location(cq.Vector(0, 0, 35)), name="height_carriage")
cutting.add(parts["blade_carrier_disc"], loc=cq.Location(cq.Vector(0, 0, 2)), name="blade_carrier")
cutting.add(parts["blade_motor_proxy"], loc=cq.Location(cq.Vector(0, 0, 39)), name="blade_motor_proxy")
for index, angle in enumerate((0, 120, 240), start=1):
    x = 116 * math.cos(math.radians(angle))
    y = 116 * math.sin(math.radians(angle))
    cutting.add(parts["replaceable_cutting_blade"], loc=cq.Location(cq.Vector(x, y, 0), cq.Vector(0, 0, 1), angle + 10), name=f"pivot_blade_{index}")
cutting.save(str(ASSEMBLY / "cutting_deck_subassembly.step"))

# Sealed laser pod subassembly, isolated for SolidWorks inspection.
laser = cq.Assembly(name="sealed_laser_pod_subassembly")
laser.add(parts["laser_pod_body"], name="pod_body")
laser.add(parts["laser_pod_lid"], loc=cq.Location(cq.Vector(0, 0, 48.5)), name="service_lid")
laser.add(parts["laser_optical_window"], loc=cq.Location(cq.Vector(28, 0, -39), cq.Vector(0, 1, 0), -25), name="optical_window")
laser.add(parts["laser_window_retainer"], loc=cq.Location(cq.Vector(29.5, 0, -42.2), cq.Vector(0, 1, 0), -25), name="window_retainer")
laser.add(parts["laser_pan_plate"], loc=cq.Location(cq.Vector(0, 0, 38)), name="internal_pan_plate")
laser.add(parts["laser_tilt_yoke"], loc=cq.Location(cq.Vector(0, 0, 5)), name="internal_tilt_yoke")
laser.add(parts["laser_emitter_cartridge"], loc=cq.Location(cq.Vector(0, 0, 5), cq.Vector(0, 1, 0), -35), name="emitter_cartridge")
laser.add(parts["laser_servo_proxy"], loc=cq.Location(cq.Vector(0, -44, 13)), name="pan_servo_proxy")
laser.add(parts["laser_pan_drive_pinion"], loc=cq.Location(cq.Vector(0, -44, 29)), name="pan_drive_pinion")
laser.add(parts["laser_servo_proxy"], loc=cq.Location(cq.Vector(0, 47.5, 5), cq.Vector(1, 0, 0), 90), name="tilt_servo_proxy")
laser.save(str(ASSEMBLY / "sealed_laser_pod_subassembly.step"))

# Internal gimbal only, for inspection and mate creation without the opaque pod.
gimbal = cq.Assembly(name="laser_internal_gimbal_service_view")
gimbal.add(parts["laser_optical_window"], loc=cq.Location(cq.Vector(28, 0, -39), cq.Vector(0, 1, 0), -25), name="optical_window")
gimbal.add(parts["laser_window_retainer"], loc=cq.Location(cq.Vector(29.5, 0, -42.2), cq.Vector(0, 1, 0), -25), name="window_retainer")
gimbal.add(parts["laser_pan_plate"], loc=cq.Location(cq.Vector(0, 0, 38)), name="pan_plate")
gimbal.add(parts["laser_tilt_yoke"], loc=cq.Location(cq.Vector(0, 0, 5)), name="tilt_yoke")
gimbal.add(parts["laser_emitter_cartridge"], loc=cq.Location(cq.Vector(0, 0, 5), cq.Vector(0, 1, 0), -35), name="emitter_cartridge")
gimbal.add(parts["laser_servo_proxy"], loc=cq.Location(cq.Vector(0, -44, 13)), name="pan_servo_proxy")
gimbal.add(parts["laser_pan_drive_pinion"], loc=cq.Location(cq.Vector(0, -44, 29)), name="pan_drive_pinion")
gimbal.add(parts["laser_servo_proxy"], loc=cq.Location(cq.Vector(0, 47.5, 5), cq.Vector(1, 0, 0), 90), name="tilt_servo_proxy")
gimbal.save(str(ASSEMBLY / "laser_internal_gimbal_service_view.step"))

# Exploded cutting system for easy SolidWorks inspection.
cutting_exploded = cq.Assembly(name="cutting_deck_exploded_view")
cutting_exploded.add(parts["cutting_deck_guard"], loc=cq.Location(cq.Vector(0, 0, -70)), name="guard")
cutting_exploded.add(parts["blade_carrier_disc"], loc=cq.Location(cq.Vector(0, 0, -20)), name="blade_carrier")
for index, angle in enumerate((0, 120, 240), start=1):
    x = 116 * math.cos(math.radians(angle))
    y = 116 * math.sin(math.radians(angle))
    cutting_exploded.add(parts["replaceable_cutting_blade"], loc=cq.Location(cq.Vector(x, y, -10), cq.Vector(0, 0, 1), angle + 10), name=f"pivot_blade_{index}")
cutting_exploded.add(parts["cut_height_carriage"], loc=cq.Location(cq.Vector(0, 0, 35)), name="height_carriage")
cutting_exploded.add(parts["blade_motor_proxy"], loc=cq.Location(cq.Vector(0, 0, 75)), name="blade_motor_proxy")
cutting_exploded.save(str(ASSEMBLY / "cutting_deck_exploded_view.step"))

# Validate all STEP exports by importing them back through OpenCascade.
validation_rows = []
for path in sorted(PARTS.glob("*.step")):
    imported = importers.importStep(str(path))
    solids = imported.solids().size()
    if solids < 1:
        raise RuntimeError(f"No solid found in {path.name}")
    box = imported.val().BoundingBox()
    validation_rows.append((path.name, solids, round(box.xlen, 2), round(box.ylen, 2), round(box.zlen, 2)))
assembly_import = importers.importStep(str(assembly_path))
if assembly_import.solids().size() < 1:
    raise RuntimeError("Assembly STEP did not import as solids")

with (DOCS / "step_validation.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["file", "solid_count", "x_mm", "y_mm", "z_mm"])
    writer.writerows(validation_rows)

print(f"Exported {len(parts)} STEP parts")
print(f"Assembly solids: {assembly_import.solids().size()}")
print(f"Assembly: {assembly_path}")
