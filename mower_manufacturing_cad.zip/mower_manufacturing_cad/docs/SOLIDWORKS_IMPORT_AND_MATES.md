# SolidWorks Import and Assembly Setup

## Import

1. Open `assembly/mower_manufacturing_assembly.step` directly in SolidWorks.
2. Enable 3D Interconnect if you want to preserve the STEP reference, or disable
   it and use **Break Link** to create native SolidWorks parts.
3. Run **Import Diagnostics** and heal any reported faces.
4. Save the result as a new `.SLDASM` with external `.SLDPRT` files.

The `parts` folder contains each component as a separate STEP if you prefer to
construct the assembly manually.

Additional inspection assemblies are included:

- `mower_service_view.step`: full mechanism without the upper cover.
- `cutting_deck_subassembly.step`: guard, motor proxy, carrier, and blades.
- `sealed_laser_pod_subassembly.step`: pod, window, internal gimbal, and actuator envelopes.
- `laser_internal_gimbal_service_view.step`: internal joints with the opaque pod removed.
- `cutting_deck_exploded_view.step`: separated guard, disc, pivot blades, carriage, and motor.

## Recommended mates

- Drive wheels: concentric mate about the Y axle; one width mate to the hub.
- Rear caster fork: concentric 20 mm kingpin/swivel mate about Z; leave rotation free.
- Rear caster wheel: concentric axle mate about Y; leave rotation free.
- Cut-height carriage: three concentric guide-rod mates plus a 25 mm limit-distance mate.
- Blade carrier: concentric to motor shaft with coincident flange face.
- Laser pod body: fix through the four 24 mm standoffs; it must never move externally.
- Laser pan plate: concentric internal Z-axis mate with +/-12 degree limit angle.
- Laser pan pinion: concentric to the fixed yaw-servo shaft; tangent/gear mate to the pan plate after replacing the proxy with the selected gearset.
- Laser tilt yoke: concentric internal Y-axis mate with +/-8 degree limit angle.
- Optical window: coincident with angled window seat; lock rotation.

STEP does not preserve SolidWorks motion mates, so the limits above must be
added after import.
