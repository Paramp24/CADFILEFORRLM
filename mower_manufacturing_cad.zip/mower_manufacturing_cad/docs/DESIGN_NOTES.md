# Manufacturing Design Notes

## Design status

This package is a dimensioned, SolidWorks-readable prototype concept. It is
not a released production design. The selected wheel motors, blade motor,
bearings, battery, laser source, optical train, electronics, fasteners, seals,
and regulatory requirements must be frozen before drawings are released.

All CAD uses millimetres. Robot axes are +X forward, +Y left, and +Z upward.
The nominal ground plane is Z = 0.

## Laser mechanism redesign

The exposed external pan/tilt mechanism was removed. The manufacturing concept
uses a fixed, sealed pod at the front of the chassis. Both rotary axes and their
actuators are inside the pod, so grass cannot wrap around the joints.

- External surface: fixed and smooth, with no moving seams.
- Window: 82 x 60 x 3 mm fused silica, angled 25 degrees to shed water and debris.
- Window seal: 1.5-2.0 mm silicone perimeter gasket compressed 20-25%.
- Window retainer: four M4 screws, removable from the underside.
- Purge provision: 6 mm inlet feeding an air knife above the window.
- Pod mounting: four 24 mm aluminum standoffs into the chassis plate.
- Internal yaw range: +/-12 degrees.
- Internal pitch range: +/-8 degrees about the nominal optical axis.
- Yaw drive: fixed internal servo and tangent pinion; finalize gear module after actuator selection.
- Nominal beam direction: approximately 35 degrees forward from vertical.
- Working target: approximately 40-100 mm in front of the mower nose.

The external window should be the lowest-cost sacrificial optical component.
Do not expose servo shafts, gears, bearings, or cable loops to the cutting area.

## Cutting mechanism

The cutting system uses a 290 mm aluminum carrier disc and three short pivoting
replaceable mower blades. Pivoting blades are preferable to one long rigid bar
because they shed impact energy if they strike a hard object.

- Nominal blade plane: 45 mm above the ground.
- Adjustment range: 30-55 mm; the upper limit preserves clearance below the guard roof.
- Height control: three 8 mm guide rods plus one T8x2 lead screw.
- Guard outside diameter: 356 mm.
- Blade carrier outside diameter: 290 mm.
- Blade collision clearance to guard: verify 10 mm minimum at every height.
- Dynamic balancing: required after the carrier, pivots, and blades are assembled.

Use certified purchased mower blades. The included blade STEP establishes the
mechanical envelope only.

## Rear caster

The rear support uses a compact 60 mm wheel so its tread, fork, and swivel fit
below the 68 mm chassis underside. A 20 mm kingpin passes through the dedicated
chassis clearance hole. The rear crossmember is split around this mount while
remaining tied together by both side rails and the front crossmember.

## Prototype manufacturing strategy

- Base plate: waterjet 4 mm 6061-T6, then CNC critical holes and datums.
- Chassis reinforcement: welded/bolted aluminum perimeter rails beneath the base plate.
- Cover interface: connected 4 mm internal frame with dedicated bracket, caster, and pod-standoff clearances.
- Upper cover: thermoformed PC-ABS/ASA or SLS PA12 for early prototypes.
- Cutting guard: spun/deep-drawn stainless or welded prototype fabrication.
- Laser pod: CNC 6061 for thermal control, or SLS PA12 for a non-powered fit check.
- Brackets: CNC or bent aluminum after motor selection.
- Fasteners: A2 stainless, thread-lock where appropriate, captive inserts in polymers.

## Required engineering before manufacture

1. Select exact wheel motors, blade motor, bearings, lead screw, battery, and laser module.
2. Replace every proxy with supplier CAD and update hole patterns.
3. Perform structural, modal, thermal, sealing, and blade-containment analyses.
4. Check centre of gravity, rollover stability, slope braking, and caster shimmy.
5. Validate optical focus through the angled window, including refraction and contamination.
6. Design dual-channel blade and laser interlocks with independent power removal.
7. Complete hazard analysis and applicable machinery, laser, EMC, and environmental compliance.
