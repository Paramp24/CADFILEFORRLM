$fn = 72;

module chamfered_prism(l, w, c, h) {
    linear_extrude(height=h)
        polygon(points=[
            [-l/2+c,-w/2], [l/2-c,-w/2], [l/2,-w/2+c], [l/2,w/2-c],
            [l/2-c,w/2], [-l/2+c,w/2], [-l/2,w/2-c], [-l/2,-w/2+c]
        ]);
}

module wheel(r, w) {
    rotate([90,0,0]) cylinder(r=r, h=w, center=true);
}

module caster_yoke() {
    color([0.18,0.20,0.22])
    translate([0,0,55])
    difference() {
        union() {
            translate([0,0,55]) cube([64,18,18], center=true);
            translate([-23,0,20]) cube([18,18,70], center=true);
            translate([23,0,20]) cube([18,18,70], center=true);
        }
        rotate([90,0,0]) cylinder(r=10,h=30,center=true);
    }
}

module mower() {
    // Wheels: front-wheel drive.
    color([0.06,0.06,0.06]) {
        translate([230,252,95]) wheel(95,56);
        translate([230,-252,95]) wheel(95,56);
    }
    color([0.28,0.30,0.32]) {
        translate([230,252,95]) wheel(44,64);
        translate([230,-252,95]) wheel(44,64);
    }

    // Rear passive casters.
    color([0.07,0.07,0.07]) {
        translate([-255,195,55]) wheel(55,36);
        translate([-255,-195,55]) wheel(55,36);
    }
    translate([-255,195,55]) caster_yoke();
    translate([-255,-195,55]) caster_yoke();

    // Main base and translucent top cover.
    color([0.15,0.18,0.20]) translate([0,0,65]) chamfered_prism(650,480,55,35);
    color([0.08,0.28,0.19,0.42]) translate([0,0,100]) chamfered_prism(610,440,70,120);

    // Front bumper and sensor pod.
    color([0.18,0.20,0.22]) translate([345,0,103]) cube([40,500,50], center=true);
    color([0.06,0.08,0.10]) translate([165,0,220]) cylinder(r=45,h=55);

    // Centered blade, ring, hub, and spindle.
    color([0.92,0.42,0.08])
        translate([65,0,20]) difference() {
            cylinder(r=180,h=50);
            translate([0,0,-1]) cylinder(r=160,h=52);
        }
    color([0.28,0.30,0.31])
        translate([65,0,42])
        linear_extrude(height=5)
        polygon(points=[[-130,-21],[130,-21],[160,0],[130,21],[-130,21],[-160,0]]);
    color([0.75,0.76,0.78]) translate([65,0,47]) cylinder(r=25,h=20);
    color([0.36,0.38,0.40]) translate([65,0,100]) cylinder(r=38,h=75);

    // Rear guarded XY laser bay.
    color([0.95,0.55,0.05])
        translate([-220,0,20])
        difference() {
            translate([0,0,42.5]) cube([210,300,85],center=true);
            translate([0,0,43.5]) cube([180,260,87],center=true);
        }
    color([0.25,0.67,0.82,0.55]) translate([-220,0,108]) cube([180,260,4],center=true);
    color([0.70,0.72,0.74]) translate([-220,0,128]) cube([160,18,12],center=true);
    color([0.25,0.30,0.34]) translate([-220,0,142]) cube([40,52,14],center=true);
    color([0.70,0.72,0.74]) translate([-220,0,157]) cube([30,250,12],center=true);
    color([0.25,0.30,0.34]) translate([-220,0,171]) cube([46,46,15],center=true);
    color([0.78,0.12,0.10]) translate([-220,0,96]) cylinder(r=18,h=75);
    color([0.88,0.16,0.12]) translate([-220,0,112]) cube([75,75,4],center=true);
}

mower();
