# Recommended SolidWorks mates

The generator places the components correctly and fixes the static enclosure parts. Add these mates before motion studies or URDF export.

## Front drive wheels

- Concentric mate: each drive-wheel/hub axis to its front axle axis
- Width or distance mate: retain the wheel's lateral position
- Leave rotation unlocked
- Motor direction: left and right wheel signs must be opposite if the mirrored installation reverses the local axle direction

## Rear casters

- Concentric mate: caster yoke swivel axis to the chassis mounting axis
- Concentric mate: caster-wheel bore axis to the yoke axle
- Coincident/width mates to retain each wheel within its yoke
- Leave both swivel and wheel rotation unlocked

## Center blade

- Concentric mate: blade/hub axis to the spindle axis
- Coincident or distance mate: blade plane at the intended cutting height
- Leave only rotation about the spindle axis unlocked
- The spindle axis must pass through the blade's geometric centre

## Rear laser XY stage

- X carriage: parallel/width mates to the X rail plus a limit-distance mate of ±60 mm from home
- Y rail: rigidly mate it to the X carriage
- Y carriage: parallel/width mates to the Y rail plus a limit-distance mate of ±110 mm from home
- Laser cylinder: rigidly mate to the Y carriage with its optical axis vertical and downward
- Safety shutter: limit-distance mate from fully closed to the mechanically verified open position
- Add hard physical stops; software limits alone are not a safety barrier

## Suggested assembly motion hierarchy for simulation

- `base_link`: chassis base
- `front_left_wheel_joint`, `front_right_wheel_joint`: powered revolute joints
- `rear_left_caster_swivel`, `rear_right_caster_swivel`: passive revolute joints
- `rear_left_caster_roll`, `rear_right_caster_roll`: passive wheel joints
- `blade_joint`: centered revolute joint
- `laser_x_joint`: limited prismatic joint
- `laser_y_joint`: limited prismatic joint
- `laser_shutter_joint`: limited prismatic joint

