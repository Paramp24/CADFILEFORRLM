#!/usr/bin/env python3
"""Create a color isometric preview without requiring SolidWorks or a display."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, Rectangle
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "preview_isometric.png"
TOP_OUT = ROOT / "preview_top_layout.png"

fig = plt.figure(figsize=(16, 10), dpi=140, facecolor="#0e1116")
ax = fig.add_subplot(111, projection="3d", facecolor="#0e1116")


def poly(faces, color, alpha=1.0, edge="#101317", lw=0.45):
    collection = Poly3DCollection(
        faces,
        facecolors=color,
        edgecolors=edge,
        linewidths=lw,
        alpha=alpha,
        shade=True,
    )
    ax.add_collection3d(collection)


def box(center, size, color, alpha=1.0):
    cx, cy, cz = center
    sx, sy, sz = (v / 2 for v in size)
    v = np.array(
        [
            [cx - sx, cy - sy, cz - sz],
            [cx + sx, cy - sy, cz - sz],
            [cx + sx, cy + sy, cz - sz],
            [cx - sx, cy + sy, cz - sz],
            [cx - sx, cy - sy, cz + sz],
            [cx + sx, cy - sy, cz + sz],
            [cx + sx, cy + sy, cz + sz],
            [cx - sx, cy + sy, cz + sz],
        ]
    )
    faces = [
        v[[0, 1, 2, 3]],
        v[[4, 5, 6, 7]],
        v[[0, 1, 5, 4]],
        v[[1, 2, 6, 5]],
        v[[2, 3, 7, 6]],
        v[[3, 0, 4, 7]],
    ]
    poly(faces, color, alpha)


def cylinder(center, radius, height, axis, color, alpha=1.0, segments=48):
    cx, cy, cz = center
    angles = np.linspace(0, 2 * np.pi, segments, endpoint=False)
    lo = []
    hi = []
    for angle in angles:
        c, s = np.cos(angle), np.sin(angle)
        if axis == "z":
            lo.append([cx + radius * c, cy + radius * s, cz - height / 2])
            hi.append([cx + radius * c, cy + radius * s, cz + height / 2])
        elif axis == "y":
            lo.append([cx + radius * c, cy - height / 2, cz + radius * s])
            hi.append([cx + radius * c, cy + height / 2, cz + radius * s])
        else:
            lo.append([cx - height / 2, cy + radius * c, cz + radius * s])
            hi.append([cx + height / 2, cy + radius * c, cz + radius * s])
    lo = np.array(lo)
    hi = np.array(hi)
    faces = [lo, hi[::-1]]
    for i in range(segments):
        j = (i + 1) % segments
        faces.append(np.array([lo[i], lo[j], hi[j], hi[i]]))
    poly(faces, color, alpha, lw=0.25)


def yoke(center):
    x, y, z = center
    color = "#394149"
    box((x, y, z + 67), (70, 22, 18), color)
    box((x - 25, y, z + 30), (18, 22, 72), color)
    box((x + 25, y, z + 30), (18, 22, 72), color)


# Ground and main running gear.
box((0, 0, -4), (790, 620, 8), "#2b382d", 0.28)
for side in (-1, 1):
    cylinder((230, side * 252, 95), 95, 56, "y", "#0a0b0c")
    cylinder((230, side * 252, 95), 44, 66, "y", "#464e55")
    cylinder((-255, side * 240, 55), 55, 36, "y", "#101113")
    yoke((-255, side * 240, 55))

# Body, cover, bumper, and sensor pod.
box((0, 0, 82.5), (700, 420, 35), "#4d5961", 0.32)
box((0, 0, 160), (650, 380, 120), "#1c8154", 0.11)
box((370, 0, 103), (40, 500, 50), "#303840")
cylinder((165, 0, 255), 45, 70, "z", "#0e151c")

# Blade system. Orange is the guarded sweep envelope.
cylinder((75, 0, 45), 180, 50, "z", "#f2760a", 0.20)
box((75, 0, 44.5), (320, 42, 5), "#565c61")
cylinder((75, 0, 57), 25, 20, "z", "#bec3c8")
cylinder((75, 0, 137.5), 38, 75, "z", "#60676d")

# Guarded rear laser bay.
bay_x = -220
orange = "#f28b08"
box((bay_x - 97.5, 0, 62.5), (15, 300, 85), orange)
box((bay_x + 97.5, 0, 62.5), (15, 300, 85), orange)
box((bay_x, -140, 62.5), (180, 20, 85), orange)
box((bay_x, 140, 62.5), (180, 20, 85), orange)
box((bay_x, 0, 110), (180, 260, 4), "#45b5d8", 0.44)

# Orthogonal X/Y stage and downward-only cylinder.
box((bay_x, 0, 130), (160, 18, 12), "#b9bdc2")
box((bay_x, 0, 145), (40, 52, 14), "#404c57")
box((bay_x, 0, 160), (30, 250, 12), "#b9bdc2")
box((bay_x, 0, 174), (46, 46, 15), "#404c57")
cylinder((bay_x, 0, 162.5), 18, 75, "z", "#cf1e19")
box((bay_x, 0, 114), (75, 75, 4), "#e62a22", 0.90)

# Labels.
label = dict(color="#f0f4f8", fontsize=10, weight="bold")
ax.text(245, 290, 205, "POWERED FRONT WHEELS", **label)
ax.text(-345, -10, 235, "GUARDED REAR X/Y BAY", **label)
ax.text(40, -30, 66, "CENTER BLADE", color="#ffb057", fontsize=9, weight="bold")

ax.set_xlim(-370, 385)
ax.set_ylim(-295, 295)
ax.set_zlim(0, 285)
ax.set_box_aspect((755, 590, 360))
ax.view_init(elev=31, azim=-53)
ax.set_axis_off()

fig.suptitle(
    "FWD AUTONOMOUS MOWER — CENTER BLADE + GUARDED REAR XY LASER BAY",
    color="#f2f5f8",
    fontsize=18,
    fontweight="bold",
    y=0.965,
)
fig.text(
    0.5,
    0.925,
    "Concept CAD • laser cylinder and cutting blade are non-functional placeholders",
    ha="center",
    color="#aeb9c4",
    fontsize=11,
)
fig.savefig(OUT, facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.15)
print(OUT)


# A clean top-layout view makes the blade and rear XY bay unambiguous.
fig2, ax2 = plt.subplots(figsize=(14, 10), dpi=140, facecolor="#0e1116")
ax2.set_facecolor("#0e1116")

ax2.add_patch(Rectangle((-350, -210), 700, 420, facecolor="#4d5961", edgecolor="#9aa5ad", alpha=0.34, linewidth=1.2))
ax2.add_patch(Rectangle((-325, -190), 650, 380, facecolor="#1c8154", edgecolor="#3ca875", alpha=0.13, linewidth=1.0))
ax2.add_patch(Rectangle((350, -250), 40, 500, facecolor="#303840", edgecolor="#a0a8b0", linewidth=1.0))

for side in (-1, 1):
    ax2.add_patch(Rectangle((135, side * 252 - 28), 190, 56, facecolor="#1b2228", edgecolor="#aeb7bf", linewidth=1.0))
    ax2.add_patch(Rectangle((-310, side * 240 - 18), 110, 36, facecolor="#22292f", edgecolor="#a5afb7", linewidth=0.9))

ax2.add_patch(Circle((75, 0), 180, facecolor="#f2760a", edgecolor="#ffad4a", alpha=0.22, linewidth=2.0))
ax2.add_patch(Rectangle((-85, -21), 320, 42, facecolor="#6a7075", edgecolor="#d8dde1", linewidth=1.1))
ax2.add_patch(Circle((75, 0), 25, facecolor="#bec3c8", edgecolor="#ffffff", linewidth=0.8))

ax2.add_patch(Rectangle((-325, -150), 210, 300, facecolor="#f28b08", edgecolor="#ffb351", alpha=0.24, linewidth=2.0))
ax2.add_patch(Rectangle((-310, -130), 180, 260, facecolor="#45b5d8", edgecolor="#8de6ff", alpha=0.23, linewidth=1.4))
ax2.add_patch(Rectangle((-300, -9), 160, 18, facecolor="#b9bdc2", edgecolor="#ffffff", linewidth=0.7))
ax2.add_patch(Rectangle((-235, -125), 30, 250, facecolor="#b9bdc2", edgecolor="#ffffff", linewidth=0.7))
ax2.add_patch(Circle((-220, 0), 18, facecolor="#cf1e19", edgecolor="#ff7770", linewidth=1.0))

ax2.annotate("Blade rotates through its geometric centre", xy=(75, 0), xytext=(95, -210), color="#ffbd6e", fontsize=12, fontweight="bold", arrowprops=dict(arrowstyle="->", color="#ffbd6e", lw=1.5))
ax2.annotate("Rear sealed XY stage\n120 mm × 220 mm travel", xy=(-220, 0), xytext=(-330, 205), color="#73dafa", fontsize=12, fontweight="bold", ha="left", arrowprops=dict(arrowstyle="->", color="#73dafa", lw=1.5))
ax2.text(225, 292, "POWERED FRONT WHEELS", color="#f0f4f8", fontsize=11, fontweight="bold", ha="center")
ax2.text(-255, -287, "PASSIVE REAR CASTERS", color="#d6dce2", fontsize=11, fontweight="bold", ha="center")
ax2.annotate("FRONT", xy=(425, 0), xytext=(365, 0), color="#f0f4f8", fontsize=11, fontweight="bold", va="center", arrowprops=dict(arrowstyle="-|>", color="#f0f4f8", lw=1.8))

ax2.annotate("", xy=(-350, -330), xytext=(390, -330), arrowprops=dict(arrowstyle="<->", color="#bbc4cc", lw=1.1))
ax2.text(20, -349, "740 mm overall", color="#bbc4cc", fontsize=10, ha="center")
ax2.annotate("", xy=(-430, -280), xytext=(-430, 280), arrowprops=dict(arrowstyle="<->", color="#bbc4cc", lw=1.1))
ax2.text(-450, 0, "560 mm overall", color="#bbc4cc", fontsize=10, ha="center", va="center", rotation=90)

ax2.set_xlim(-485, 455)
ax2.set_ylim(-375, 350)
ax2.set_aspect("equal", adjustable="box")
ax2.axis("off")
fig2.suptitle("TOP LAYOUT — BLADE AND REAR XY LASER BAY", color="#f2f5f8", fontsize=19, fontweight="bold", y=0.97)
fig2.text(0.5, 0.93, "Nominal concept dimensions in millimetres", color="#aeb9c4", fontsize=11, ha="center")
fig2.savefig(TOP_OUT, facecolor=fig2.get_facecolor(), bbox_inches="tight", pad_inches=0.18)
print(TOP_OUT)
