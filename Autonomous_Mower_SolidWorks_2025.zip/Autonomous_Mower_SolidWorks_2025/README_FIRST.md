# Autonomous mower — SolidWorks 2025 generator

This package creates true native, editable SolidWorks files on a Windows computer that has SolidWorks 2025 installed.

## Generate the files

1. Extract the ZIP to a normal local folder such as `C:\CAD\Autonomous_Mower`.
2. Close any unsaved SolidWorks documents.
3. Double-click `Run_Generator.bat`.
4. If Windows asks, allow the script to run. SolidWorks will open and generate the files in `Generated_Native_CAD`.
5. Open `Autonomous_Mower_FWD_XY_Laser.SLDASM` from that folder.

The generator creates 20 individual `.SLDPRT` files and one `.SLDASM`. It does not rename STEP/STL files; SolidWorks itself creates and saves the native files.

## Architecture

- Approximate overall envelope: 740 × 560 × 290 mm
- Two powered front wheels (front-wheel drive)
- Two passive rear caster wheels
- 320 mm rotary-blade placeholder, centered laterally and rotating through its own geometric centre; the deck is shifted 75 mm forward to separate it from the rear laser bay
- Rear, sealed two-axis laser positioning bay
  - X travel: fore/aft carriage
  - Y travel: left/right carriage
  - Cylindrical laser placeholder remains vertical and points only downward
  - Guard frame, optical window, and normally closed shutter isolate the beam path
- Front bumper and top sensor pod placeholders

## Important limitations

This is a concept-level mechanical layout, not a certified or production-ready mower. The cutting blade is an envelope placeholder; use a commercially manufactured and dynamically balanced blade/spindle system. The laser cylinder contains no optical, electrical, wavelength, power, or focusing specification. Do not install or energize a hazardous laser from this model alone.

The assembly is spatially arranged. Static enclosure parts are fixed where possible; the blade, wheels, casters, and X/Y carriages are intentionally left movable so you can add the mates listed in `MATE_SETUP.md`.

## Editing dimensions

The parts contain native sketches and boss-extrude features. You can edit them in SolidWorks. For a clean full redesign, edit the clearly marked **USER PARAMETERS** block near the top of `Generate_Autonomous_Mower_SolidWorks.vbs`, delete `Generated_Native_CAD`, and rerun the generator.

## Compatibility

- Target: SolidWorks 2025, English UI
- Uses the default Part and Assembly templates configured in SolidWorks
- If your reference planes are not named `Top Plane` and `Front Plane`, edit the two plane-name constants near the top of the script
