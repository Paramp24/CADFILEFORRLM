Option Explicit

' Autonomous residential mower concept generator for SolidWorks 2025.
' All API geometry values are in metres.
' The generated files are native SLDPRT/SLDASM documents with sketches and extrusions.

Const SW_DEFAULT_TEMPLATE_PART = 1
Const SW_DEFAULT_TEMPLATE_ASSEMBLY = 2
Const SW_DOC_PART = 1
Const SW_OPEN_SILENT = 1
Const SW_SAVE_CURRENT = 0
Const SW_SAVE_SILENT = 1

' ========================= USER PARAMETERS =========================
Const TOP_PLANE_NAME = "Top Plane"
Const FRONT_PLANE_NAME = "Front Plane"

Const BODY_LENGTH = 0.700
Const BODY_WIDTH = 0.420
Const BODY_CORNER = 0.055
Const BODY_BASE_THICKNESS = 0.035
Const BODY_BASE_Y = 0.065

Const COVER_LENGTH = 0.650
Const COVER_WIDTH = 0.380
Const COVER_CORNER = 0.070
Const COVER_HEIGHT = 0.120
Const COVER_Y = 0.100

Const DRIVE_WHEEL_RADIUS = 0.095
Const DRIVE_WHEEL_WIDTH = 0.056
Const DRIVE_WHEEL_X = 0.230
Const DRIVE_WHEEL_CENTER_Y = 0.095
Const DRIVE_WHEEL_CENTER_Z = 0.252

Const CASTER_RADIUS = 0.055
Const CASTER_WIDTH = 0.036
Const CASTER_X = -0.255
Const CASTER_CENTER_Y = 0.055
Const CASTER_CENTER_Z = 0.240

Const BLADE_CENTER_X = 0.075
Const BLADE_LENGTH = 0.320
Const BLADE_WIDTH = 0.042
Const BLADE_THICKNESS = 0.005
Const BLADE_Y = 0.042
Const BLADE_GUARD_OUTER_RADIUS = 0.180
Const BLADE_GUARD_INNER_RADIUS = 0.160
Const BLADE_GUARD_HEIGHT = 0.050
Const BLADE_GUARD_Y = 0.020

Const LASER_BAY_CENTER_X = -0.220
Const LASER_BAY_OUTER_LENGTH = 0.210
Const LASER_BAY_OUTER_WIDTH = 0.300
Const LASER_BAY_INNER_LENGTH = 0.180
Const LASER_BAY_INNER_WIDTH = 0.260
Const LASER_BAY_WALL_HEIGHT = 0.085
Const LASER_BAY_Y = 0.020
Const LASER_X_TRAVEL = 0.120
Const LASER_Y_TRAVEL = 0.220
Const LASER_RADIUS = 0.018
' ==================================================================

Dim swApp, fso, scriptDir, outDir, partTemplate, asmTemplate
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
outDir = fso.BuildPath(scriptDir, "Generated_Native_CAD")

If Not fso.FolderExists(outDir) Then fso.CreateFolder outDir

On Error Resume Next
Set swApp = GetObject(, "SldWorks.Application")
If swApp Is Nothing Then
    Err.Clear
    Set swApp = CreateObject("SldWorks.Application")
End If
If Err.Number <> 0 Or swApp Is Nothing Then
    WScript.Echo "ERROR: SolidWorks could not be started. Install/activate SolidWorks 2025 and try again."
    WScript.Quit 2
End If
On Error GoTo 0

swApp.Visible = True
partTemplate = swApp.GetUserPreferenceStringValue(SW_DEFAULT_TEMPLATE_PART)
asmTemplate = swApp.GetUserPreferenceStringValue(SW_DEFAULT_TEMPLATE_ASSEMBLY)

If Len(partTemplate) = 0 Then Fail "No default SolidWorks Part template is configured."
If Len(asmTemplate) = 0 Then Fail "No default SolidWorks Assembly template is configured."

WScript.Echo "Generating native parts..."

CreateChamferedPrism "01_Chassis_Base.SLDPRT", TOP_PLANE_NAME, BODY_LENGTH, BODY_WIDTH, BODY_CORNER, BODY_BASE_THICKNESS, 0.15, 0.18, 0.20, 0.00, "Chassis_Base_Extrusion"
CreateChamferedPrism "02_Top_Cover.SLDPRT", TOP_PLANE_NAME, COVER_LENGTH, COVER_WIDTH, COVER_CORNER, COVER_HEIGHT, 0.08, 0.28, 0.19, 0.08, "Top_Cover_Extrusion"
CreateCylinderPart "03_Front_Drive_Wheel.SLDPRT", FRONT_PLANE_NAME, DRIVE_WHEEL_RADIUS, DRIVE_WHEEL_WIDTH, 0.08, 0.08, 0.08, 0.00, "Drive_Wheel_Extrusion"
CreateCylinderPart "04_Front_Drive_Hub.SLDPRT", FRONT_PLANE_NAME, 0.044, 0.064, 0.24, 0.27, 0.29, 0.00, "Drive_Hub_Extrusion"
CreateCylinderPart "05_Rear_Caster_Wheel.SLDPRT", FRONT_PLANE_NAME, CASTER_RADIUS, CASTER_WIDTH, 0.10, 0.10, 0.10, 0.00, "Caster_Wheel_Extrusion"
CreateCasterYoke "06_Rear_Caster_Yoke.SLDPRT", 0.018, 0.18, 0.20, 0.22, 0.00
CreateAnnulusPart "07_Blade_Guard_Ring.SLDPRT", TOP_PLANE_NAME, BLADE_GUARD_OUTER_RADIUS, BLADE_GUARD_INNER_RADIUS, BLADE_GUARD_HEIGHT, 0.92, 0.42, 0.08, 0.00, "Blade_Guard_Extrusion"
CreateBladePart "08_Cutting_Blade_PLACEHOLDER.SLDPRT", 0.28, 0.30, 0.31, 0.00
CreateCylinderPart "09_Blade_Spindle_Housing.SLDPRT", TOP_PLANE_NAME, 0.038, 0.075, 0.36, 0.38, 0.40, 0.00, "Spindle_Housing_Extrusion"
CreateCylinderPart "10_Blade_Hub.SLDPRT", TOP_PLANE_NAME, 0.025, 0.020, 0.75, 0.76, 0.78, 0.00, "Blade_Hub_Extrusion"
CreateRectFramePart "11_Laser_Safety_Housing.SLDPRT", LASER_BAY_OUTER_LENGTH, LASER_BAY_OUTER_WIDTH, LASER_BAY_INNER_LENGTH, LASER_BAY_INNER_WIDTH, LASER_BAY_WALL_HEIGHT, 0.95, 0.55, 0.05, 0.00, "Laser_Guard_Wall_Extrusion"
CreateBoxPart "12_Laser_Optical_Window.SLDPRT", TOP_PLANE_NAME, LASER_BAY_INNER_LENGTH, LASER_BAY_INNER_WIDTH, 0.004, 0.25, 0.67, 0.82, 0.62, "Optical_Window_Extrusion"
CreateBoxPart "13_Laser_X_Rail.SLDPRT", TOP_PLANE_NAME, LASER_X_TRAVEL + 0.040, 0.018, 0.012, 0.70, 0.72, 0.74, 0.00, "X_Rail_Extrusion"
CreateBoxPart "14_Laser_X_Carriage.SLDPRT", TOP_PLANE_NAME, 0.040, 0.052, 0.014, 0.25, 0.30, 0.34, 0.00, "X_Carriage_Extrusion"
CreateBoxPart "15_Laser_Y_Rail.SLDPRT", TOP_PLANE_NAME, 0.030, LASER_Y_TRAVEL + 0.030, 0.012, 0.70, 0.72, 0.74, 0.00, "Y_Rail_Extrusion"
CreateBoxPart "16_Laser_Y_Carriage.SLDPRT", TOP_PLANE_NAME, 0.046, 0.046, 0.015, 0.25, 0.30, 0.34, 0.00, "Y_Carriage_Extrusion"
CreateCylinderPart "17_Laser_Cylinder_PLACEHOLDER.SLDPRT", TOP_PLANE_NAME, LASER_RADIUS, 0.075, 0.78, 0.12, 0.10, 0.00, "Laser_Cylinder_Extrusion"
CreateBoxPart "18_Laser_Safety_Shutter.SLDPRT", TOP_PLANE_NAME, 0.075, 0.075, 0.004, 0.88, 0.16, 0.12, 0.00, "Safety_Shutter_Extrusion"
CreateBoxPart "19_Front_Bumper.SLDPRT", TOP_PLANE_NAME, 0.040, 0.500, 0.050, 0.18, 0.20, 0.22, 0.00, "Front_Bumper_Extrusion"
CreateCylinderPart "20_Sensor_Pod_PLACEHOLDER.SLDPRT", TOP_PLANE_NAME, 0.045, 0.070, 0.06, 0.08, 0.10, 0.00, "Sensor_Pod_Extrusion"

WScript.Echo "Building native assembly..."
CreateAssembly
WriteGeneratedManifest

WScript.Echo "SUCCESS: Native SolidWorks files were created in:"
WScript.Echo outDir
WScript.Quit 0

Sub CreateBoxPart(fileName, planeName, lengthValue, widthValue, depthValue, redValue, greenValue, blueValue, transparencyValue, featureName)
    Dim model, ok, feat
    Set model = NewPart(fileName)
    ok = SelectPlane(model, planeName)
    If Not ok Then Fail "Could not select plane '" & planeName & "' while creating " & fileName
    model.SketchManager.InsertSketch True
    model.SketchManager.CreateCenterRectangle 0, 0, 0, lengthValue / 2, widthValue / 2, 0
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Extrusion failed for " & fileName
    feat.Name = featureName
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateChamferedPrism(fileName, planeName, lengthValue, widthValue, cornerValue, depthValue, redValue, greenValue, blueValue, transparencyValue, featureName)
    Dim model, ok, feat, points
    Set model = NewPart(fileName)
    ok = SelectPlane(model, planeName)
    If Not ok Then Fail "Could not select plane '" & planeName & "' while creating " & fileName
    points = ChamferedRectanglePoints(lengthValue, widthValue, cornerValue)
    model.SketchManager.InsertSketch True
    DrawClosedPolygon model, points
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Extrusion failed for " & fileName
    feat.Name = featureName
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateCylinderPart(fileName, planeName, radiusValue, depthValue, redValue, greenValue, blueValue, transparencyValue, featureName)
    Dim model, ok, feat
    Set model = NewPart(fileName)
    ok = SelectPlane(model, planeName)
    If Not ok Then Fail "Could not select plane '" & planeName & "' while creating " & fileName
    model.SketchManager.InsertSketch True
    model.SketchManager.CreateCircleByRadius 0, 0, 0, radiusValue
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Extrusion failed for " & fileName
    feat.Name = featureName
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateAnnulusPart(fileName, planeName, outerRadius, innerRadius, depthValue, redValue, greenValue, blueValue, transparencyValue, featureName)
    Dim model, ok, feat
    Set model = NewPart(fileName)
    ok = SelectPlane(model, planeName)
    If Not ok Then Fail "Could not select plane '" & planeName & "' while creating " & fileName
    model.SketchManager.InsertSketch True
    model.SketchManager.CreateCircleByRadius 0, 0, 0, outerRadius
    model.SketchManager.CreateCircleByRadius 0, 0, 0, innerRadius
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Annular extrusion failed for " & fileName
    feat.Name = featureName
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateRectFramePart(fileName, outerLength, outerWidth, innerLength, innerWidth, depthValue, redValue, greenValue, blueValue, transparencyValue, featureName)
    Dim model, ok, feat
    Set model = NewPart(fileName)
    ok = SelectPlane(model, TOP_PLANE_NAME)
    If Not ok Then Fail "Could not select top plane while creating " & fileName
    model.SketchManager.InsertSketch True
    model.SketchManager.CreateCenterRectangle 0, 0, 0, outerLength / 2, outerWidth / 2, 0
    model.SketchManager.CreateCenterRectangle 0, 0, 0, innerLength / 2, innerWidth / 2, 0
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Frame extrusion failed for " & fileName
    feat.Name = featureName
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateBladePart(fileName, redValue, greenValue, blueValue, transparencyValue)
    Dim model, ok, feat, points, halfLength, halfWidth, nose
    halfLength = BLADE_LENGTH / 2
    halfWidth = BLADE_WIDTH / 2
    nose = 0.030
    points = Array( _
        Array(-halfLength + nose, -halfWidth), _
        Array( halfLength - nose, -halfWidth), _
        Array( halfLength, 0), _
        Array( halfLength - nose, halfWidth), _
        Array(-halfLength + nose, halfWidth), _
        Array(-halfLength, 0))
    Set model = NewPart(fileName)
    ok = SelectPlane(model, TOP_PLANE_NAME)
    If Not ok Then Fail "Could not select top plane while creating " & fileName
    model.SketchManager.InsertSketch True
    DrawClosedPolygon model, points
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, BLADE_THICKNESS)
    If feat Is Nothing Then Fail "Blade extrusion failed for " & fileName
    feat.Name = "Balanced_Blade_Envelope_Extrusion"
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Sub CreateCasterYoke(fileName, depthValue, redValue, greenValue, blueValue, transparencyValue)
    Dim model, ok, feat, points
    points = Array( _
        Array(-0.032, 0.080), _
        Array( 0.032, 0.080), _
        Array( 0.032,-0.010), _
        Array( 0.014,-0.010), _
        Array( 0.014, 0.055), _
        Array(-0.014, 0.055), _
        Array(-0.014,-0.010), _
        Array(-0.032,-0.010))
    Set model = NewPart(fileName)
    ok = SelectPlane(model, FRONT_PLANE_NAME)
    If Not ok Then Fail "Could not select front plane while creating " & fileName
    model.SketchManager.InsertSketch True
    DrawClosedPolygon model, points
    model.SketchManager.InsertSketch True
    Set feat = ExtrudeSelectedSketch(model, depthValue)
    If feat Is Nothing Then Fail "Caster yoke extrusion failed for " & fileName
    feat.Name = "Caster_Yoke_Extrusion"
    ApplyAppearance model, redValue, greenValue, blueValue, transparencyValue
    SaveAndClose model, fso.BuildPath(outDir, fileName)
End Sub

Function NewPart(fileName)
    Dim model
    Set model = swApp.NewDocument(partTemplate, 0, 0, 0)
    If model Is Nothing Then Fail "SolidWorks could not create a new part for " & fileName
    model.ClearSelection2 True
    Set NewPart = model
End Function

Function SelectPlane(model, planeName)
    model.ClearSelection2 True
    SelectPlane = model.Extension.SelectByID2(planeName, "PLANE", 0, 0, 0, False, 0, Nothing, 0)
End Function

Function ExtrudeSelectedSketch(model, depthValue)
    Set ExtrudeSelectedSketch = model.FeatureManager.FeatureExtrusion2( _
        True, False, False, 0, 0, depthValue, 0.010, _
        False, False, False, False, 0.0174532925199433, 0.0174532925199433, _
        False, False, False, False, True, True, True, 0, 0, False)
End Function

Sub DrawClosedPolygon(model, points)
    Dim i, j, p1, p2
    For i = 0 To UBound(points)
        j = i + 1
        If j > UBound(points) Then j = 0
        p1 = points(i)
        p2 = points(j)
        model.SketchManager.CreateLine p1(0), p1(1), 0, p2(0), p2(1), 0
    Next
End Sub

Function ChamferedRectanglePoints(lengthValue, widthValue, cornerValue)
    Dim hx, hw
    hx = lengthValue / 2
    hw = widthValue / 2
    ChamferedRectanglePoints = Array( _
        Array(-hx + cornerValue, -hw), _
        Array( hx - cornerValue, -hw), _
        Array( hx, -hw + cornerValue), _
        Array( hx, hw - cornerValue), _
        Array( hx - cornerValue, hw), _
        Array(-hx + cornerValue, hw), _
        Array(-hx, hw - cornerValue), _
        Array(-hx, -hw + cornerValue))
End Function

Sub ApplyAppearance(model, redValue, greenValue, blueValue, transparencyValue)
    Dim materialValues(8)
    materialValues(0) = redValue
    materialValues(1) = greenValue
    materialValues(2) = blueValue
    materialValues(3) = 0.35
    materialValues(4) = 0.75
    materialValues(5) = 0.35
    materialValues(6) = 0.30
    materialValues(7) = transparencyValue
    materialValues(8) = 0.00
    model.MaterialPropertyValues = materialValues
End Sub

Sub SaveAndClose(model, fullPath)
    Dim saveErrors, saveWarnings, saved, title
    saveErrors = 0
    saveWarnings = 0
    title = model.GetTitle
    model.ForceRebuild3 False
    saved = model.Extension.SaveAs(fullPath, SW_SAVE_CURRENT, SW_SAVE_SILENT, Nothing, saveErrors, saveWarnings)
    If Not saved Then Fail "Save failed for " & fullPath & " (errors=" & saveErrors & ", warnings=" & saveWarnings & ")"
    swApp.CloseDoc title
End Sub

Sub CreateAssembly()
    Dim asmModel, asmDoc, assemblyPath, saveErrors, saveWarnings, saved
    Set asmModel = swApp.NewDocument(asmTemplate, 0, 0, 0)
    If asmModel Is Nothing Then Fail "SolidWorks could not create a new assembly."
    Set asmDoc = asmModel

    AddComponent asmModel, asmDoc, "01_Chassis_Base.SLDPRT", 0, BODY_BASE_Y, 0, "Chassis_Base", True
    AddComponent asmModel, asmDoc, "02_Top_Cover.SLDPRT", 0, COVER_Y, 0, "Top_Cover", True

    AddComponent asmModel, asmDoc, "03_Front_Drive_Wheel.SLDPRT", DRIVE_WHEEL_X, DRIVE_WHEEL_CENTER_Y, DRIVE_WHEEL_CENTER_Z - DRIVE_WHEEL_WIDTH / 2, "Front_Left_Drive_Wheel", False
    AddComponent asmModel, asmDoc, "03_Front_Drive_Wheel.SLDPRT", DRIVE_WHEEL_X, DRIVE_WHEEL_CENTER_Y, -DRIVE_WHEEL_CENTER_Z - DRIVE_WHEEL_WIDTH / 2, "Front_Right_Drive_Wheel", False
    AddComponent asmModel, asmDoc, "04_Front_Drive_Hub.SLDPRT", DRIVE_WHEEL_X, DRIVE_WHEEL_CENTER_Y, DRIVE_WHEEL_CENTER_Z - 0.032, "Front_Left_Drive_Hub", False
    AddComponent asmModel, asmDoc, "04_Front_Drive_Hub.SLDPRT", DRIVE_WHEEL_X, DRIVE_WHEEL_CENTER_Y, -DRIVE_WHEEL_CENTER_Z - 0.032, "Front_Right_Drive_Hub", False

    AddComponent asmModel, asmDoc, "05_Rear_Caster_Wheel.SLDPRT", CASTER_X, CASTER_CENTER_Y, CASTER_CENTER_Z - CASTER_WIDTH / 2, "Rear_Left_Caster_Wheel", False
    AddComponent asmModel, asmDoc, "05_Rear_Caster_Wheel.SLDPRT", CASTER_X, CASTER_CENTER_Y, -CASTER_CENTER_Z - CASTER_WIDTH / 2, "Rear_Right_Caster_Wheel", False
    AddComponent asmModel, asmDoc, "06_Rear_Caster_Yoke.SLDPRT", CASTER_X, CASTER_CENTER_Y, CASTER_CENTER_Z - 0.009, "Rear_Left_Caster_Yoke", False
    AddComponent asmModel, asmDoc, "06_Rear_Caster_Yoke.SLDPRT", CASTER_X, CASTER_CENTER_Y, -CASTER_CENTER_Z - 0.009, "Rear_Right_Caster_Yoke", False

    AddComponent asmModel, asmDoc, "07_Blade_Guard_Ring.SLDPRT", BLADE_CENTER_X, BLADE_GUARD_Y, 0, "Blade_Guard_Ring", True
    AddComponent asmModel, asmDoc, "08_Cutting_Blade_PLACEHOLDER.SLDPRT", BLADE_CENTER_X, BLADE_Y, 0, "Centered_Cutting_Blade", False
    AddComponent asmModel, asmDoc, "09_Blade_Spindle_Housing.SLDPRT", BLADE_CENTER_X, BODY_BASE_Y + BODY_BASE_THICKNESS, 0, "Blade_Spindle_Housing", True
    AddComponent asmModel, asmDoc, "10_Blade_Hub.SLDPRT", BLADE_CENTER_X, BLADE_Y + BLADE_THICKNESS, 0, "Blade_Hub", False

    AddComponent asmModel, asmDoc, "11_Laser_Safety_Housing.SLDPRT", LASER_BAY_CENTER_X, LASER_BAY_Y, 0, "Rear_Laser_Safety_Housing", True
    AddComponent asmModel, asmDoc, "12_Laser_Optical_Window.SLDPRT", LASER_BAY_CENTER_X, 0.108, 0, "Laser_Optical_Window", True
    AddComponent asmModel, asmDoc, "13_Laser_X_Rail.SLDPRT", LASER_BAY_CENTER_X, 0.128, 0, "Laser_X_Rail_Fixed", True
    AddComponent asmModel, asmDoc, "14_Laser_X_Carriage.SLDPRT", LASER_BAY_CENTER_X, 0.142, 0, "Laser_X_Carriage_Moving", False
    AddComponent asmModel, asmDoc, "15_Laser_Y_Rail.SLDPRT", LASER_BAY_CENTER_X, 0.157, 0, "Laser_Y_Rail_Moving", False
    AddComponent asmModel, asmDoc, "16_Laser_Y_Carriage.SLDPRT", LASER_BAY_CENTER_X, 0.171, 0, "Laser_Y_Carriage_Moving", False
    AddComponent asmModel, asmDoc, "17_Laser_Cylinder_PLACEHOLDER.SLDPRT", LASER_BAY_CENTER_X, 0.125, 0, "Downward_Laser_Cylinder_PLACEHOLDER", False
    AddComponent asmModel, asmDoc, "18_Laser_Safety_Shutter.SLDPRT", LASER_BAY_CENTER_X, 0.112, 0, "Normally_Closed_Safety_Shutter", False

    AddComponent asmModel, asmDoc, "19_Front_Bumper.SLDPRT", 0.370, 0.078, 0, "Front_Safety_Bumper", True
    AddComponent asmModel, asmDoc, "20_Sensor_Pod_PLACEHOLDER.SLDPRT", 0.165, COVER_Y + COVER_HEIGHT, 0, "Autonomy_Sensor_Pod_PLACEHOLDER", True

    asmModel.ForceRebuild3 False
    On Error Resume Next
    asmModel.ShowNamedView2 "*Isometric", 7
    asmModel.ViewZoomtofit2
    On Error GoTo 0

    assemblyPath = fso.BuildPath(outDir, "Autonomous_Mower_FWD_XY_Laser.SLDASM")
    saveErrors = 0
    saveWarnings = 0
    saved = asmModel.Extension.SaveAs(assemblyPath, SW_SAVE_CURRENT, SW_SAVE_SILENT, Nothing, saveErrors, saveWarnings)
    If Not saved Then Fail "Assembly save failed (errors=" & saveErrors & ", warnings=" & saveWarnings & ")"
End Sub

Sub AddComponent(asmModel, asmDoc, partFile, xValue, yValue, zValue, instanceName, makeFixed)
    Dim partPath, openedPart, openErrors, openWarnings, activateErrors, asmTitle, component, selected
    partPath = fso.BuildPath(outDir, partFile)
    openErrors = 0
    openWarnings = 0
    Set openedPart = swApp.OpenDoc6(partPath, SW_DOC_PART, SW_OPEN_SILENT, "", openErrors, openWarnings)
    If openedPart Is Nothing Then Fail "Could not load component " & partFile

    asmTitle = asmModel.GetTitle
    activateErrors = 0
    swApp.ActivateDoc3 asmTitle, False, 0, activateErrors
    Set component = asmDoc.AddComponent5(partPath, 0, "", False, "", xValue, yValue, zValue)
    If component Is Nothing Then Fail "Could not add component " & partFile & " to the assembly."
    On Error Resume Next
    component.Name2 = instanceName
    On Error GoTo 0

    If makeFixed Then
        On Error Resume Next
        asmModel.ClearSelection2 True
        selected = component.Select4(False, Nothing, False)
        If selected Then asmDoc.FixComponent
        asmModel.ClearSelection2 True
        On Error GoTo 0
    End If
End Sub

Sub WriteGeneratedManifest()
    Dim manifest, fileName, folder, fileItem
    Set manifest = fso.CreateTextFile(fso.BuildPath(outDir, "GENERATED_FILES_AND_STATUS.txt"), True)
    manifest.WriteLine "Autonomous mower native SolidWorks package"
    manifest.WriteLine "Generated: " & Now
    manifest.WriteLine "Assembly: Autonomous_Mower_FWD_XY_Laser.SLDASM"
    manifest.WriteLine ""
    manifest.WriteLine "Architecture: two powered front wheels, two rear casters, centered rotary blade, rear sealed XY laser bay."
    manifest.WriteLine "Blade and laser geometry are placeholders only; see SAFETY_AND_MANUFACTURING_NOTES.md."
    manifest.WriteLine ""
    manifest.WriteLine "Files:"
    Set folder = fso.GetFolder(outDir)
    For Each fileItem In folder.Files
        manifest.WriteLine "- " & fileItem.Name
    Next
    manifest.Close
End Sub

Sub Fail(message)
    WScript.Echo "ERROR: " & message
    WScript.Quit 1
End Sub
