@echo off
setlocal
cd /d "%~dp0"
echo Creating native SolidWorks parts and assembly...
cscript //nologo "Generate_Autonomous_Mower_SolidWorks.vbs"
if errorlevel 1 (
  echo.
  echo The generator stopped with an error. Read the message above.
  pause
  exit /b 1
)
echo.
echo Complete. Open the Generated_Native_CAD folder.
pause

