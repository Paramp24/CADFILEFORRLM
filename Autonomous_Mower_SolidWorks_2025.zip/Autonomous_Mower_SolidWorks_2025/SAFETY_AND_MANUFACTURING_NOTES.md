# Safety and manufacturing notes

## Status

This package is a concept CAD layout. It is not a released production design, a safety certification, or authorization to build or energize the cutting/laser systems. A qualified mechanical engineer, functional-safety engineer, laser-safety specialist, and accredited test laboratory must review the final product.

## Mechanical safeguards represented in the CAD

- Blade is centred laterally and rotates about its geometric centre on an independent spindle axis. Its deck is shifted 75 mm forward to maintain separation from the rear laser bay.
- A continuous side guard surrounds the blade's sweep envelope.
- The laser is in a separate rear bay, not co-located with the blade.
- The laser mechanism is an orthogonal XY stage, so the cylindrical placeholder always points downward.
- The beam path is bounded by a guard frame, optical window, mechanical travel stops, and normally closed shutter.
- Two front powered wheels and two rear casters provide a four-point support polygon.
- A front bumper is included as a contact-sensing placeholder.

## Required control interlocks before any hazardous prototype

Use a safety-rated architecture. At minimum, the laser command should require all of the following continuously:

- Blade command is zero and independently verified stopped.
- Vehicle command is zero and wheel motion is independently verified stopped.
- Service cover and laser housing interlocks are closed.
- Lift sensors confirm all support points are on the ground.
- Tilt is within a validated safe limit.
- Ground-proximity sensors confirm that the guarded underside is close enough to block line-of-sight escape.
- Person/pet/obstacle detection is clear and independently monitored.
- Both emergency-stop channels are healthy.
- Shutter-position feedback proves the shutter opens only after all other conditions are valid.
- Laser power feedback agrees with the commanded state; disagreement forces power removal.

The blade and laser should be mutually exclusive at the hardware safety-controller level, not only in ROS 2 or application software.

## Manufacturing work still required

- Replace the blade placeholder with a rated, commercially manufactured, dynamically balanced blade and spindle assembly.
- Complete blade-tip containment, thrown-object, impact, lift, tilt, ingress, thermal, vibration, braking, and abuse testing.
- Size bearings, shafts, fasteners, motors, brakes, and wheel traction from verified loads and duty cycles.
- Add drainage, labyrinth seals, debris wipers, cable chains, and replaceable sacrificial optical-window protection for the XY bay.
- Complete tolerance stacks and interference checks at both travel limits and all caster angles.
- Select materials and wall thicknesses only after structural and impact analysis.
- Conduct a formal hazard analysis/FMEA and independent design review.

## Laser boundary

The red cylinder is only a mechanical keep-out envelope. The package intentionally contains no wavelength, optical power, pulse duration, focal length, energy density, exposure time, or beam-control recommendation. Those values must come from a qualified laser-safety design and product classification process.
